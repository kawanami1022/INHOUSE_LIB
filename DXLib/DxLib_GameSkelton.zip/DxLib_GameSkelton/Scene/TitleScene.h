#pragma once
#include "BaseScene.h"
class TitleScene :
    public BaseScene
{
public:
    unique_Base Input(unique_Base);
    unique_Base upDate(unique_Base);
    void Draw();
private:
    TitleScene();
    ~TitleScene();
};

