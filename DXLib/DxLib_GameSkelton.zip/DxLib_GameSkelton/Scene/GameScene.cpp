#include <DxLib.h>
#include "GameScene.h"


unique_Base GameScene::Input(unique_Base nowScene)
{

	return std::move(nowScene);
}

unique_Base GameScene::upDate(unique_Base nowScene)
{

	return std::move(nowScene);
}

void GameScene::Draw()
{
	ClsDrawScreen();
	DrawFormatString(0, 0, 0xff0000, "GameScene");
	ScreenFlip();
}

GameScene::GameScene()
{
}

GameScene::~GameScene()
{
}
