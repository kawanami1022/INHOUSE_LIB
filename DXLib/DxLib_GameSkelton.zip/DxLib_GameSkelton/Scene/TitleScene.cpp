#include <iostream>
#include <memory>
#include <utility>
#include "TitleScene.h"

unique_Base TitleScene::Input(unique_Base nowScene)
{
    return std::make_unique;
}

unique_Base TitleScene::upDate(unique_Base nowScene)
{
    return unique_Base();
}

void TitleScene::Draw()
{
}

TitleScene::TitleScene()
{
}

TitleScene::~TitleScene()
{
}
