#pragma once
#include <cstdlib>
#include <memory>
#include <iostream>
#include "BaseScene.h"

class GameScene:public BaseScene
{
public:
	virtual unique_Base Input(unique_Base);
	virtual unique_Base upDate(unique_Base);
	virtual void Draw();
	GameScene();
	~GameScene();

private:
};

