#pragma once
bool IsHitAABB(const Rect A, const Rect B);
bool IsHitCircle(const Circle A, const Circle B);